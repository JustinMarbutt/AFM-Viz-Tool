/* Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
/* File for "Terrain" lesson of the OpenGL tutorial on
 * www.videotutorialsrock.com
 */



#include <iostream>
#include <stdlib.h>
#include <fstream>

#ifdef __APPLE__
#include <OpenGL/OpenGL.h>
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include "imageloader.h"
#include "vec3f.h"

using namespace std;

//Represents a terrain, by storing a set of heights and normals at 2D locations
class Terrain {
	private:
		int w; //Width
		int l; //Length
		float** hs; //Heights
		Vec3f** normals;
		bool computedNormals; //Whether normals is up-to-date
	public:
		Terrain(int w2, int l2) {
			w = w2;
			l = l2;
			
			hs = new float*[l];
			for(int i = 0; i < l; i++) {
				hs[i] = new float[w];
			}
			
			normals = new Vec3f*[l];
			for(int i = 0; i < l; i++) {
				normals[i] = new Vec3f[w];
			}
			
			computedNormals = false;
		}
		
		~Terrain() {
			for(int i = 0; i < l; i++) {
				delete[] hs[i];
			}
			delete[] hs;
			
			for(int i = 0; i < l; i++) {
				delete[] normals[i];
			}
			delete[] normals;
		}
		
		int width() {
			return w;
		}
		
		int length() {
			return l;
		}
		
		//Sets the height at (x, z) to y
		void setHeight(int x, int z, float y) {
			hs[z][x] = y;
			computedNormals = false;
		}
		
		//Returns the height at (x, z)
		float getHeight(int x, int z) {
			return hs[z][x];
		}
		
		//Computes the normals, if they haven't been computed yet
		void computeNormals() {
			if (computedNormals) {
				return;
			}
			
			//Compute the rough version of the normals
			Vec3f** normals2 = new Vec3f*[l];
			for(int i = 0; i < l; i++) {
				normals2[i] = new Vec3f[w];
			}
			
			for(int z = 0; z < l; z++) {
				for(int x = 0; x < w; x++) {
					Vec3f sum(0.0f, 0.0f, 0.0f);
					
					Vec3f out;
					if (z > 0) {
						out = Vec3f(0.0f, hs[z - 1][x] - hs[z][x], -1.0f);
					}
					Vec3f in;
					if (z < l - 1) {
						in = Vec3f(0.0f, hs[z + 1][x] - hs[z][x], 1.0f);
					}
					Vec3f left;
					if (x > 0) {
						left = Vec3f(-1.0f, hs[z][x - 1] - hs[z][x], 0.0f);
					}
					Vec3f right;
					if (x < w - 1) {
						right = Vec3f(1.0f, hs[z][x + 1] - hs[z][x], 0.0f);
					}
					
					if (x > 0 && z > 0) {
						sum += out.cross(left).normalize();
					}
					if (x > 0 && z < l - 1) {
						sum += left.cross(in).normalize();
					}
					if (x < w - 1 && z < l - 1) {
						sum += in.cross(right).normalize();
					}
					if (x < w - 1 && z > 0) {
						sum += right.cross(out).normalize();
					}
					
					normals2[z][x] = sum;
				}
			}
			
			//Smooth out the normals
			
			const float FALLOUT_RATIO = 0.5f;
			for(int z = 0; z < l; z++) {
				for(int x = 0; x < w; x++) {
					Vec3f sum = normals2[z][x];
					
					if (x > 0) {
						sum += normals2[z][x - 1] * FALLOUT_RATIO;
					}
					if (x < w - 1) {
						sum += normals2[z][x + 1] * FALLOUT_RATIO;
					}
					if (z > 0) {
						sum += normals2[z - 1][x] * FALLOUT_RATIO;
					}
					if (z < l - 1) {
						sum += normals2[z + 1][x] * FALLOUT_RATIO;
					}
					
					if (sum.magnitude() == 0) {
						sum = Vec3f(0.0f, 1.0f, 0.0f);
					}
					normals[z][x] = sum;
				}
			}
			
			
			for(int i = 0; i < l; i++) {
				delete[] normals2[i];
			}
			delete[] normals2;
			
			computedNormals = true;
		}
		
		//Returns the normal at (x, z)
		Vec3f getNormal(int x, int z) {
			if (!computedNormals) {
				computeNormals();
			}
			return normals[z][x];
		}
};


float maxHeight = -9999999.0f, minHeight = 99999999.0f;
float thresh = 0.0f;
//Loads a terrain from a heightmap.  The heights of the terrain range from
//-height / 2 to height / 2.
Terrain* loadTerrain(const char* filename, float height) 
{
	ifstream data (filename);
  	float f;
  	float h;
  	data >> f;
  	data >> f;
  	//TODO: make resolution variable
    float temp[200][200]; 
    int i;
    int j;
    for(j = 0; j < 200; j++)
    {
      for(i = 0; i < 200; i++)
      {
        data >> f;
        temp[i][j] = f;
      }
    }
    
	Terrain* t = new Terrain(200, 200);
  	//Read in and interpolate data
	j = 0;

 
  for(int y = 0; y < 200; y++)
  {
    i=0;
	for(int x = 0; x < 200; x++)
    {
    	h = temp[x][y];
		t->setHeight(x, y, h*5);

	}

   
  }
  
	t->computeNormals();
	
	for(int z = 0; z < t->length() - 5; z++) 
	{
		
		for(int x = t->width() - 4; x > 1; x--)
    	{
        	if( t->getHeight(x, z) > maxHeight)
        		maxHeight = t->getHeight(x, z);
        	if( t->getHeight(x, z) < minHeight)
        		minHeight = t->getHeight(x, z);
        		
        	f = f + t->getHeight(x, z);
        	
			
			
		
    	}

   	 	
	}
	/*
	f = f / (200 * 200);
	cout << "Maximum: " << maxHeight << "\n";
	cout << "Minimum: " << minHeight << "\n";
	cout << "Average: " << f << "\n";
	//cin >> thresh;
	*/
	
	
	
	for(int z = 0; z < t->length() - 5; z++) 
	{
		
		for(int x = t->width() - 4; x > 1; x--)
    	{
        	if( t->getHeight(x, z) < thresh)
        		t -> setHeight(x, z, 0);
		
    	}
	
	}

	
	return t;
}


float _angle = 60.0f;
float _angleLat = 60.0f;
float _angleLon = 0.0f;
float _walk = -10.0f;
float _stride = 0.0f;
float _elevate = 0.0f;
Terrain* _terrain;

void cleanup() {
	delete _terrain;
}

void handleKeypress(unsigned char key, int x, int y) {
	switch (key) {
		
		case 27: //Escape key
		
			cleanup();
			exit(0);
			break;
			
		case 97: // A key
		
			_angleLat += 2.0f;
			if (_angleLat > 360) {
			_angleLat -= 360;
			}
	
			glutPostRedisplay();
			break;
			
		case 100: // D key

			_angleLat -= 2.0f;
			if (_angleLat < 0) {
			_angleLat -= 360;
			}
	
			glutPostRedisplay();
			break;
			
		case 119: // W key
		
			_angleLon += 2.0f;
			if (_angleLon > 360) {
			_angleLon -= 360;
			}
	
			glutPostRedisplay();
			break;
			
		case 115: // S key

			_angleLon -= 2.0f;
			if (_angleLon < 0) {
			_angleLon -= 360;
			}
	
			glutPostRedisplay();
			break;
			
		case 105: // I key
		
			_walk += 0.5f;
			
	
			glutPostRedisplay();
			break;
			
		case 107: // K key

			_walk -= 0.5f;
			
	
			glutPostRedisplay();
			break;
			
		case 106: // J key
		
			_stride += 0.5f;
			
	
			glutPostRedisplay();
			break;
			
		case 108: // L key

			_stride -= 0.5f;
			
	
			glutPostRedisplay();
			break;
			
		case 113: // Q key
		
			_elevate += 0.5f;
			
	
			glutPostRedisplay();
			break;
			
		case 101: // E key

			_elevate -= 0.5f;
			
	
			glutPostRedisplay();
			break;
			
	    
			
	}
	
	//printf("%d\n",key);
}


void initRendering() {
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glShadeModel(GL_SMOOTH);
}

void handleResize(int w, int h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (double)w / (double)h, 1.0, 200.0);
}

void drawScene() 
{
	
	
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(_stride, _elevate, _walk);
	glTranslatef(0.0f, 0.0f, 4.0f);
	glTranslatef(0.0f, -2.45f, 2.5f);
	glRotatef(0.0f, 0.0f, 0.0f, 0.0f);
	
	glRotatef(-_angleLat, 0.0f, 1.0f, 0.0f);
	glRotatef(-_angleLon, -_angleLon, 1.0f, 0.0f);
	glRotatef(60.0f, 0.0f, 1.0f, 0.0f);
	
	GLfloat ambientColor[] = {0.4f, 0.4f, 0.4f, 1.0f};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientColor);
	
	GLfloat lightColor0[] = {0.6f, 0.6f, 0.6f, 1.0f};
	GLfloat lightPos0[] = {-0.5f, 0.8f, 0.1f, 0.0f};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor0);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos0);
	GLfloat lightColor1[] = {0.6f, 0.6f, 0.6f, 1.0f};
	GLfloat lightPos1[] = {-1.5f, 0.9f, 1.1f, 0.0f};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor1);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos1);
	
	
	float scale = 5.0f / max(_terrain->width() - 1, _terrain->length() - 1);
	glScalef(scale, scale, scale);
	glTranslatef(-(float)(_terrain->width() - 1) / 2, 0.0f, -(float)(_terrain->length() - 1) / 2);
  	glShadeModel (GL_SMOOTH);       // Enables Smooth Color Shading
    glEnable (GL_LINE_SMOOTH);
    
    

	glColor3f(0.2f, 0.4f, 1.0f);

	
	for(int z = 0; z < _terrain->length() - 5; z++) 
	{
		//Makes OpenGL draw a triangle at every three consecutive vertices
		glBegin(GL_TRIANGLE_STRIP);
		
		for(int x = _terrain->width() - 4; x > 1; x--)
    	{
    		
    			
        		//glColor3f(_terrain->getHeight(x, z)/maxHeight, _terrain->getHeight(x, z)/maxHeight-0.5f, 1/(_terrain->getHeight(x, z)/maxHeight)+.001f);
        		
        			
	
     		
      			Vec3f normal = _terrain->getNormal(x, z);
				glNormal3f(normal[0], normal[2], normal[1]);
				glVertex3f(x, z, 0);
				normal = _terrain->getNormal(x, z + 1);
				glNormal3f(normal[0], normal[2], normal[1]);
				glVertex3f(x, z+1, 0);
				/*
				if(_terrain->getHeight(x, z) > thresh)
				{
					gluSphere(quadratic,_terrain->getHeight(x, z),x,z);
				}
				*/
				
     			
			
		
    	}
    	

   	 	glEnd();
   	 	
	}
	
	//glutSwapBuffers();
}

void drawScene2() 
{
	
	
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	
	GLfloat ambientColor[] = {0.4f, 0.4f, 0.4f, 1.0f};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientColor);
	
	GLfloat lightColor0[] = {0.6f, 0.6f, 0.6f, 1.0f};
	GLfloat lightPos0[] = {-0.5f, 0.8f, 0.1f, 0.0f};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor0);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos0);
	GLfloat lightColor1[] = {0.6f, 0.6f, 0.6f, 1.0f};
	GLfloat lightPos1[] = {-1.5f, 0.9f, 1.1f, 0.0f};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor1);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos1);
	
	
	
    
    

	glColor3f(0.3f, 0.9f, 0.4f);
	glTranslatef(-2.6f, -2.1f, 0.0f);
	float dx =  5.5f / maxHeight ;
	
	float x = 0;
	float y = 0;
	for(; x < 5.5f; x += dx)
	{
		glBegin(GL_QUADS);
		
			glVertex3f(x, 0, -5.0f);
			glVertex3f(x+dx, 0, -5.0f);
			glVertex3f(x, y+dx, -5.0f);
			glVertex3f(x+dx, y+dx, -5.0f);
    		
    	
    	

   	 	glEnd();
   	 	y += dx;
	}
   	 	
	
	
	//glutSwapBuffers();
}

char* fn;
void update(int value)
{
	glutTimerFunc(25, update, 0);
	thresh += 1.0f;
	_terrain = loadTerrain(fn, 20);
	glutPostRedisplay();
	
}

void winDisplay()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	int w = 500;
	int h = 400;
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (double)w / (double)h, 1.0, 200.0);
	drawScene2();


	glViewport(0, 400, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (double)w / (double)h, 1.0, 200.0);
	drawScene();
	
	glutSwapBuffers();
	
}

int main(int argc, char** argv) {
	
	fn = argv[1];
	_terrain = loadTerrain(fn, 20);
	
	glutInit(&argc, argv);
	int w = 500;
	int h = 800;
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(w, h);
	
	glutCreateWindow("Surface Visualization");
	
	glutKeyboardFunc(handleKeypress);
	glutReshapeFunc(handleResize);
	glutTimerFunc(25, update, 0);
	glutDisplayFunc(winDisplay);
	initRendering();
	
	glutMainLoop();
	return 0;
	
}









